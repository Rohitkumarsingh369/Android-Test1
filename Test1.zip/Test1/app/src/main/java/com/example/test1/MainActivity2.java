package com.example.test1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView idshow,stdnameshow,branchshow,cgpashow,sexshow,spinnershow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        idshow=findViewById(R.id.stdid);
        stdnameshow=findViewById(R.id.nameshow);
        branchshow=findViewById(R.id.branch);
        cgpashow=findViewById(R.id.cgpa);
        sexshow=findViewById(R.id.sex);
        spinnershow=findViewById(R.id.special);
        Intent intent=getIntent();
        String id=intent.getStringExtra("idp");
        String name=intent.getStringExtra("stdp");
        String branch=intent.getStringExtra("stdb");
        String cgpa=intent.getStringExtra("stdc");
        String sex=intent.getStringExtra("sex");
        String spinner=intent.getStringExtra("subjectp");
        idshow.setText("ID no. : "+id);
        stdnameshow.setText("Name : "+name);
        branchshow.setText("Branch : "+branch);
        cgpashow.setText("CGPA : "+cgpa);
        sexshow.setText("Sex : "+sex);
        spinnershow.setText("Specialization : "+spinner);
    }
}