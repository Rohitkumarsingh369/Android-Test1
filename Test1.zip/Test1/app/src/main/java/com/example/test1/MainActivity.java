package com.example.test1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    Button submit;
    EditText id,name,branch,cgpa;
    RadioGroup radioGroup;
    String sex,subjectp;
    Spinner spinner1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        submit=findViewById(R.id.submitbtn);
        id=findViewById(R.id.idnum);
        name=findViewById(R.id.stdname);
        branch=findViewById(R.id.stdbranch);
        cgpa=findViewById(R.id.stdcgpa);
        spinner1=findViewById(R.id.spinner);
         String []subject={"IOT","BigData","Java","Python"};
        ArrayAdapter<String>adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,subject);
        spinner1.setAdapter(adapter);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch(i){
                    case 0:
                          subjectp=spinner1.getItemAtPosition(i).toString();
                        break;
                    case 1:
                        subjectp=spinner1.getSelectedItem().toString();
                        break;
                    case 2:
                        subjectp=spinner1.getSelectedItem().toString();
                        break;
                    case 3:
                        subjectp=spinner1.getSelectedItem().toString();
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + i);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

            radioGroup=findViewById(R.id.radiogrp);
            radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup radioGroup, int i) {
                    switch (i){
                        case R.id.malebtn:
                            sex="Male";
                            break;
                        case R.id.femalebtn:
                            sex="Female";
                            break;
                    }
                }
            });
        submit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String idp=id.getText().toString();
                String stdp=name.getText().toString();
                String stdb=branch.getText().toString();
                String stdc=cgpa.getText().toString();

                Intent intent=new Intent(getApplicationContext(),MainActivity2.class);
                intent.putExtra("idp",idp);
                intent.putExtra("stdp",stdp);
                intent.putExtra("stdb",stdb);
                intent.putExtra("stdc",stdc);
                intent.putExtra("sex",sex);
                intent.putExtra("subjectp",subjectp);
                startActivity(intent);
            }
        });
    }
}